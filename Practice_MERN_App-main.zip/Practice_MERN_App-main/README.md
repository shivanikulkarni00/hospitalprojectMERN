# Practice_MERN_App
Mini project of Doctor and Patient registration using MongoDB, Express.js, React.js, Node.js
